using ToDoListWebApp.Models;

namespace ToDoListWebApp.Services
{
    public class TodoService
    {
        private readonly List<TodoItem> _tasks = new();
        private int _nextId = 1;

        public IEnumerable<TodoItem> GetPendingTasks()
        {
            // Sort by Priority (High first) then by Deadline
            return _tasks
                .Where(t => !t.IsCompleted)
                .OrderBy(t => t.Priority == "High" ? 0 : t.Priority == "Medium" ? 1 : 2)
                .ThenBy(t => t.Deadline ?? DateTime.MaxValue)
                .ToList();
        }

        public IEnumerable<TodoItem> GetCompletedTasks()
        {
            return _tasks
                .Where(t => t.IsCompleted)
                .OrderByDescending(t => t.CreatedAt)
                .ToList();
        }

        public void AddTask(string title, string priority, DateTime? deadline)
        {
            if (string.IsNullOrWhiteSpace(title)) return;

            _tasks.Add(new TodoItem
            {
                Id = _nextId++,
                Title = title.Trim(),
                Priority = string.IsNullOrWhiteSpace(priority) ? "Medium" : priority,
                Deadline = deadline,
                IsCompleted = false,
                CreatedAt = DateTime.Now
            });
        }

        public void MarkAsDone(int id)
        {
            var task = _tasks.FirstOrDefault(t => t.Id == id);
            if (task != null)
            {
                task.IsCompleted = true;
            }
        }

        public void MarkAsNotDone(int id)
        {
            var task = _tasks.FirstOrDefault(t => t.Id == id);
            if (task != null)
            {
                task.IsCompleted = false;
            }
        }

        public void RemoveTask(int id)
        {
            var task = _tasks.FirstOrDefault(t => t.Id == id);
            if (task != null)
            {
                _tasks.Remove(task);
            }
        }

        public void ClearAll()
        {
            _tasks.Clear();
        }

        public void ClearPending()
        {
            _tasks.RemoveAll(t => !t.IsCompleted);
        }

        public void ClearCompleted()
        {
            _tasks.RemoveAll(t => t.IsCompleted);
        }
    }
}
