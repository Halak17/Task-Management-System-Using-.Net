namespace ToDoListWebApp.Models
{
    public class TodoItem
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Priority { get; set; } = "Medium"; // High, Medium, Low
        public DateTime? Deadline { get; set; }
        public bool IsCompleted { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        public string PriorityBadgeClass
        {
            get
            {
                return Priority switch
                {
                    "High" => "bg-danger",
                    "Medium" => "bg-warning text-dark",
                    "Low" => "bg-info text-dark",
                    _ => "bg-secondary"
                };
            }
        }

        public string FormattedDeadline
        {
            get
            {
                if (Deadline == null) return "No deadline";
                return Deadline.Value.ToString("dd MMM yyyy, hh:mm tt");
            }
        }

        public bool IsOverdue
        {
            get
            {
                return !IsCompleted && Deadline.HasValue && Deadline.Value < DateTime.Now;
            }
        }
    }
}
