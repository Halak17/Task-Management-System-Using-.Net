using Microsoft.AspNetCore.Mvc;

namespace ToDoListWebApp.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return RedirectToAction("Index", "Todo");
        }

        public IActionResult Error()
        {
            return View();
        }
    }
}
