using Microsoft.AspNetCore.Mvc;
using ToDoListWebApp.Services;

namespace ToDoListWebApp.Controllers
{
    public class TodoController : Controller
    {
        private readonly TodoService _todoService;

        public TodoController(TodoService todoService)
        {
            _todoService = todoService;
        }

        // GET: /Todo
        public IActionResult Index()
        {
            ViewBag.PendingTasks = _todoService.GetPendingTasks();
            ViewBag.CompletedTasks = _todoService.GetCompletedTasks();
            return View();
        }

        // POST: /Todo/Add
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Add(string title, string priority, string deadlineDate, string deadlineTime)
        {
            if (string.IsNullOrWhiteSpace(title))
            {
                TempData["Error"] = "Please write a task.";
                return RedirectToAction(nameof(Index));
            }

            DateTime? deadline = null;

            if (!string.IsNullOrWhiteSpace(deadlineDate))
            {
                string dateTimeString = deadlineDate;
                if (!string.IsNullOrWhiteSpace(deadlineTime))
                {
                    dateTimeString += " " + deadlineTime;
                }
                else
                {
                    dateTimeString += " 23:59";
                }

                if (DateTime.TryParse(dateTimeString, out DateTime parsedDeadline))
                {
                    deadline = parsedDeadline;
                }
            }

            _todoService.AddTask(title, priority, deadline);
            return RedirectToAction(nameof(Index));
        }

        // POST: /Todo/Done
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Done(int id)
        {
            _todoService.MarkAsDone(id);
            return RedirectToAction(nameof(Index));
        }

        // POST: /Todo/NotDone
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult NotDone(int id)
        {
            _todoService.MarkAsNotDone(id);
            return RedirectToAction(nameof(Index));
        }

        // POST: /Todo/Remove
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Remove(int id)
        {
            _todoService.RemoveTask(id);
            return RedirectToAction(nameof(Index));
        }

        // POST: /Todo/ClearAll
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult ClearAll()
        {
            _todoService.ClearAll();
            return RedirectToAction(nameof(Index));
        }

        // POST: /Todo/ClearPending
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult ClearPending()
        {
            _todoService.ClearPending();
            return RedirectToAction(nameof(Index));
        }
    }
}
