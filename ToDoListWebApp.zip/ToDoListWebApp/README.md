# Simple To-Do List Web Application

ASP.NET Core MVC Web Application converted from the original Windows Forms desktop project.

## Features

- Add new tasks
- Mark tasks as **Done** (moves to Completed list)
- Move tasks back to **Pending** (Not Done)
- Remove individual tasks
- Clear all pending tasks
- Clear all tasks

## Technologies

- **ASP.NET Core 8** (MVC)
- **C#**
- **Bootstrap 5** (simple & clean UI)
- In-memory storage (no database required)

## How to Run

1. Open the folder in **Visual Studio 2022** or **VS Code**
2. Make sure you have **.NET 8 SDK** installed
3. Run the project:
   ```bash
   dotnet restore
   dotnet run
   ```
4. Open browser at: `http://localhost:5000`

## Project Structure

```
ToDoListWebApp/
├── Controllers/
│   ├── TodoController.cs
│   └── HomeController.cs
├── Models/
│   └── TodoItem.cs
├── Services/
│   └── TodoService.cs
├── Views/
│   ├── Todo/Index.cshtml
│   └── Shared/_Layout.cshtml
├── wwwroot/css/site.css
├── Program.cs
└── ToDoListWebApp.csproj
```

## Original Project

Converted from a simple Windows Forms (WinForms) C# To-Do List application.
